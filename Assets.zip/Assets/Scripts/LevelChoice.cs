using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class LevelChoice : MonoBehaviour
{
    public void StartGameEz()
    {
        SceneManager.LoadScene("Eazy");
    }

    public void StartGameHard()
    {
        SceneManager.LoadScene("Hard");
    }

}
